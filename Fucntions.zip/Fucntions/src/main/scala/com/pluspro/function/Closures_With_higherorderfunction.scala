package com.pluspro.function

import java.util.Calendar

object Closures_With_higherorderfunction {


  def main(args: Array[String]): Unit = {


    // assign Method to function

    val greeting_USA = Greeting("English")

    // Pass name parameter

    greeting_USA("deen")



    val greeting_Srilanka = Greeting("Sinhala")
    greeting_Srilanka("Anu")


  }

  def Greeting (lang : String)={

var Currendate = Calendar.getInstance().getTime().toString



    lang match {

      case "English"=>(selectlang : String) =>println("Hello "+selectlang+" It is " +Currendate)

      case "Sinhala"=>(selectlang : String)=>println("Ayubowan "+selectlang+" It is " +Currendate)




    }



  }



}
