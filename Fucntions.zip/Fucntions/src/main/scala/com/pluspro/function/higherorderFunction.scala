package com.pluspro.function

object higherorderFunction {

 // Example 1
  def Salarmaker(basic : Int , total : Int=>AnyVal): Unit ={


    println(total(basic))


  }

  def AddAllowance (basic : Int): Int ={

    basic + 3000

  }

//  Salarmaker(5000,AddAllowance)

  // example 2



  // 1. def prosalarymaker( MakeBasicSalary(3000),Makeallovance ):
  // 2. def prosalarymaker( 5000,Makeallovance ):


  def prosalarymaker( salary : Int , getAllowance : Int=>AnyVal ,getIncriment : Int=>AnyVal,DeductSala : Int=>AnyVal): Unit ={


     //  getAllowance(MakeBasicSalary(3000))
// this getAllowance == Makeallovance
       //        getAllowance(5000)

    // call with allowancc
    println(getAllowance(salary))

    // call  with allowance
    println(getIncriment(salary))

    // call mainfucntion with deduct salary
    println(DeductSala(salary))
  }


  //
  def MakeBasicSalary(basic : Int) : Int ={

    basic + 2000


  }

  def DeductSalaFunction(blabla : Int): Int={

    blabla - 2000

  }

  def GetAllowance (basicsalary : Int): Int ={

    basicsalary+  2000
  }

  def GetIncriment (basicsalary : Int): Int ={

    basicsalary+  1000
  }
  def main(args: Array[String]): Unit = {


    prosalarymaker(MakeBasicSalary(3000),GetAllowance,GetIncriment,DeductSalaFunction)
    //Salarmaker(5000,AddAllowance)

  }


}
