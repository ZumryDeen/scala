

object Pfunction{

  def main(args: Array[String]): Unit = {


     //partial

    // 1
    val SetMail = (val1 : String , val2 : String) => val1 + val2;
    val mail = SetMail(_:String,"@ymail.com")

    println(mail("Deeno"))






// 2
    val sum = (num1 : Int , num2 : Int) => num1 + num2
    val sum2 = sum(_:Int,5)



    println(sum(2,5))


    println(sum2(5))



  }


}