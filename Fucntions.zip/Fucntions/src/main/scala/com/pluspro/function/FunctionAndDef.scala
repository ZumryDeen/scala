package com.pluspro.function

object FunctionvsDef {


  def main(args: Array[String]): Unit = {


    // its a Def
    def GetSal(basic: Int): Int = {

      val totalsalary = basic + 5000
      totalsalary

    }

    // this is a fuctiin similar to Def
    val Getsalfun = (basicsal: Int) => {
      val totalsalaryfun = basicsal + 5000
      totalsalaryfun

    }: Int


    // this is a funtion declaration standerd
    val getTotalpay = //function name
      (fixedpay: Int, Commintion: Int) => // parameter passing line
        {
          fixedpay + Commintion
        } //  expressiom
          : Int // return (Optional)

    // convert def into functio
    // 1. asigning def for val (function )

    val GetsalFun: Int => Int = GetSal
    // 2. asigning def for val (function ) wiht _ (Eta)
    val GetsalFun2  =  GetSal _


    println(GetsalFun2(300))
    println(getTotalpay(200, 100))
    println(GetSal(10000))
    println(Getsalfun(5000))

  }


}