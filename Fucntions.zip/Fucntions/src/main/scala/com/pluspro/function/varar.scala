package com.pluspro.function

object varar {

  def main(args: Array[String]): Unit = {


parameterAtt("a","b","c","d")(1,2,3,4)


  }


  def parameterAtt (strinarray : String* )(Intarr : Int*) ={

   println(strinarray,Intarr)

  }


}
