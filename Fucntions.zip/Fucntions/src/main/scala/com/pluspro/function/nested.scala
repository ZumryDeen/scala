package com.pluspro.function

// Nested function  will use when u need to write all sub function related to a class in on class Ex : calculation salary , employer register

object NestedDemo{



  def Salary(basic : Int , allowance : Int , insentive : Int)={

    def Addpromotion(currentsalary : Int , incriment : Int): Int ={


      println(incriment)
      currentsalary + incriment


    }

    // 1. Addpromotion(basic ,Addpromotion(2000,1000))
    // 2. Addpromotion(basic ,3000)
    //2. Addpromotion(10000 ,3000)


    Addpromotion(basic,Addpromotion(allowance,insentive))



  }

  def main(args: Array[String]): Unit = {

    println(Salary(10000,2000,1000))

  }





}