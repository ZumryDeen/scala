package com.pluspro.function

class convertmthodtofunction {



  // 1. Method converted to function
def salaryMaker (Basic : Int,Allowance : Int): Int ={

  Basic + Allowance
}

  // _ call Eta ecstenction
val salaryfun = salaryMaker _



 // 2. anonymous function

val funanonymous = (x : Int , y : Int)=>{

  x + y

} : Int



}
