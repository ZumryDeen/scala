package com.pluspro.function

object currying {

  // currying is similer to partial fucntion

  def add(num1 : Int)(num2:Int)={

    num1+num2


  }


  def main(args: Array[String]): Unit = {

    //
    println(add(10)(5))

var call = add(10)_

    var test2 = call(3)
    println(test2)

  }



}
