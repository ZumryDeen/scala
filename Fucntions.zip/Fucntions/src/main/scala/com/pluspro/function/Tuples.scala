package com.pluspro.function

object Tuples {




  def main(args: Array[String]): Unit = {



/*    val area = getRectangleArea(5,8)

    def getRectangleArea (length:Double, breadth:Double):Double = {length * breadth}

    val area = getRectangleArea(5,8)

    val perimeterOfSquare = 20.0

    (getRectangleArea _).tupled(
    { val sideOfSquare = perimeterOfSquare/4;
    (sideOfSquare,sideOfSquare)

    })
    res119: Double = 6.25*/



    def getRectangleArea(Hight : Int , Width : Int) : Int={

      Hight * Width
    }

    val Getsize = getRectangleArea(2,4)

    val proposedsize = 20;





/*val totalBox   = 20;

val Onsideofbox = totalBox/ 4


val area = Totalcoveradgeofbox(Onsideofbox,Onsideofbox)*/



  }



}

