package com.pluspro.function

object BynameParameter {


  def sayHello(hello : String) : String={

    println("this is 1st")

    hello

  }

 /* def greetingsMorning( greet :=> String) : String ={


    println("Good morining")
    greet
  }*/

/*  def main(args: Array[String]): Unit = {

    println(greetingsMorning(sayHello("deen")))


  }*/



}
