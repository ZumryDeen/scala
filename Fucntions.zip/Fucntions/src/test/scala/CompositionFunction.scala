


object CompositionFunction{


  def main(args: Array[String]): Unit = {


var PrintSalary = DoubleSalary(IncrimantSalary(20000))

println(PrintSalary)

  }





  def DoubleSalary(Num1: Int) : Int ={


Num1*2


  }




  def IncrimantSalary(IncAmount : Int) : Int={

    IncAmount+2000

  }


}