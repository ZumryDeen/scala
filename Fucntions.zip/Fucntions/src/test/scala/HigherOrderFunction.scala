

object HigherOrder {



  def Domath (func1 : Int ,func2 : Int => AnyVal ): Unit = {

     println(func2(func1))



  }


  def Mutipleby2(Num1 : Int): Int ={

    Num1 * 2


  }


  def main(args: Array[String]): Unit = {

    Domath(25,Mutipleby2)

  }



}