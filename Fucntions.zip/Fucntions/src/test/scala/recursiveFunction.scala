object recursiveFunction {

// nore recursive
  def Function1(  num1 : Int) : Int ={

    var x = num1
    var y = 1

    while (x>0){

      y = y*x
      x = x -1

    }

    return y

  }




// recursive

  def function2(num2 : Int) : Int = {


    if(num2 <=0){

      //throw new Exception("boom")

     return 1

    } else {  return num2* function2(num2-1)}

  }


  def main(args: Array[String]): Unit = {


    println(Function1(5))
    println(function2(5))

    lazy val testlazy = Function1(10)/Function1(5)

    val nonlazy = Function1(10)/Function1(5)

    println(testlazy)


  }

}
