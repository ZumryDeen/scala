

object Demo {


  def main(args: Array[String]): Unit = {


    def MakeitDuble(Mynum: Int): Int = Mynum * 2


    println(MakeitDuble(5))


    // Assing functiont to val
    val myfun = MakeitDuble(_)

// call function by val
    println(myfun(10))


    val r = 1 to 10

    println(r)

  //  r.map(MakeitDuble(2))

  }

}