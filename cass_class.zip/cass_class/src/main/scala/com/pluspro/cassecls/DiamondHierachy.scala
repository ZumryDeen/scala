package com.pluspro.cassecls



trait Component {

  def description : String


}


trait Transmitter extends Component {

  def generateParams : String


}


trait  Recever extends Component {

def   receiveParam : String

}


trait Radio extends Transmitter with Recever{


}

