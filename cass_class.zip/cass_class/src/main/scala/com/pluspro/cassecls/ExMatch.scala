package com.pluspro.cassecls

case class  MsgTest (name :String , Mail : String)

object Demo{

  def main(args: Array[String]): Unit = {

    val msg1 = MsgTest("deeos","deen@gmail.com")

    val msg2 = MsgTest("deeo","deen@gmail.com")

    println("Hello world working")
    println(msg1.name)

val test = msg1==msg2

    println(test)

  }
}

