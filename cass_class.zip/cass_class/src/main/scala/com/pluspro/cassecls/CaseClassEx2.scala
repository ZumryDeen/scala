package com.pluspro.cassecls

/*class Work {

  def sayhello(): Unit = {

    println("bye deen its time to go")

  }


}*/

trait  Notifications

case class Email(sender: String, title: String, body: String) extends Notifications

case class SMS(caller: String, message: String) extends Notifications

case class VoiceRecording(contactName: String, link: String) extends Notifications









object notfyTEs {

  def main(args: Array[String]): Unit = {


    println("hellow im from Ex2")

    val additionalPeople = Seq("077545454","rrrr","deen@gmail.com")

    val sendsms = SMS("777778", "whats ur age")
    val voicerec = VoiceRecording("Tom", "easydrive.com")

    val emailmsg  = Email("deen@gmail.com","warning","mail body")

   //showNotificationEx2(sendsms,additionalPeople)

    println(showNotificationEx2(SMS("777778", "whats ur age"),additionalPeople))

    println(showNotificationEx2(voicerec,additionalPeople))
    println(showNotificationEx2(emailmsg,additionalPeople))



    /*   val talk = new Work
       function2()

       talk.sayhello()
       println("hello im main 4 from class")*/

  }


  /* def function2(): Unit = {

     println("this is from function 2")


   }*/


  def showNotificationEx2(notyobj: Notifications, morePeople : Seq[String]): String = {

    notyobj match {

  /*    case Email(emailad, _, _) if morePeople contains(emailad)=> s"you got email $emailad in more people list"

      case SMS(number, message) => s"you got  msg from this number $number said $message"

      case VoiceRecording(name, link) => s"voice got voice mail from $name and link is $link"*/

      case Email(emailad, _, _) if morePeople contains(emailad)=> "1"

      case SMS(number, message) => "2"

      case VoiceRecording(name, link) => "3"

    }
  }


}