package com.pluspro.cassecls

/*class Work {

  def sayhello(): Unit = {

    println("bye deen its time to go")

  }


}

abstract class Notifications

case class Email2(sender: String, title: String, body: String) extends Notifications

case class SMS2(caller: String, message: String) extends Notifications

case class VoiceRecording2(contactName: String, link: String) extends Notifications


object NotifyObj {

  def main(args: Array[String]): Unit = {


    println("hellow im from Ex2")

    val sendsms = SMS2("777778", "whats ur age")
    val voicerec = VoiceRecording2("Tom", "easydrive.com")

    val emailmsg  = Email2("deen@gmail.com","warning","mail body")

    var test = showNotification(sendsms)
    println(showNotification(voicerec))
    println(showNotification(emailmsg))
    println(test)
       val talk = new Work
       function2()

       talk.sayhello()
       println("hello im main 4 from class")

  }


   def function2(): Unit = {

     println("this is from function 2")


   }


  def showNotification(notyobj: Notifications): String = {

    notyobj match {

      case Email2(email, title, body) => s"you got email from $email with title $title and body is $body"

      case SMS2(number, message) => s"you got  msg from this number $number said $message"

      case VoiceRecording2(name, link) => s"voice got voice mail from $name and link is $link"
    }
  }


}
*/
