package com.pluspro.cassecls



  sealed  trait Humanchek {



  def Planet (planetName : String , Alien :Boolean)


}
 case class IshumanCheck(Legs : Int, looks :String, Hands : Int) extends Humanchek{

   def showlegs: Unit ={


     println(Legs)

   }


   override def Planet(planetName: String, Alien: Boolean): Unit = {

     println(planetName)

   }

 }
 class Istakingcheck(Sound : String, talk : Boolean)
 class WhatsEatingCheck(EatsHand : String, Drink : Boolean)





object Demos {

  def specciesTes: Unit ={


  // var myclass = new Ishuman(2,"looks human",2);




  }




  def main(args: Array[String]): Unit = {


    var myclass =  IshumanCheck(2,"looks human",2);
    var planetdef = myclass.Planet("mars",true)
    myclass.showlegs

    planetdef

  }

}



/*
case class Istaking (Sound : String , talk : Boolean) extends Humanchek{


}
*/


/*
case class WhatsEating (EatsHand : String , Drink : Boolean) extends Humanchek


case object Cehckwhat extends Humanchek{}*/


