package com.pluspro.cassecls

object CasePatternGuurd{


  def main(args: Array[String]): Unit = {


    println("helllo world")

    val daysinweek = "Sunday"

    val Dayilfter = daysinweek match {


      case "Monday" => "its Monday"
      case "Tuesday"=> "itstueday"
      case someOtherday if someOtherday =="Friday" => "its a good day"
      case someOtherday if someOtherday =="Sunday" => "its a sleepy day"

    }

// if not mathc case option 1 = value binder

    val weekend ="Poya"

    val DaymatcherWeekend = weekend match {


      case "sunday" => "its sunday"
      case "satday" =>"its  sat day"
      case getday =>{

        println(s"Hi deen its not weekend its $getday")


      }

    }


    println(Dayilfter)
    println(DaymatcherWeekend)



    // match expressions: down casting with Pattern Variables
    val num1:Any = 10.5

    val Showtype = num1 match {

      case num1:Int =>"Intiger"
      case num1:String =>"String"
      case othertype =>{

        println(s"the type is $othertype")

      }


    }


    println(Showtype)

  }














}
