package com.pluspro.cassecls




   trait Bread

  case class Ishuman(Legs: Int, looks: String, Hands: Int) extends Bread

  case class Istaking(Sound: String, talk: Boolean) extends Bread

  case class WhatsEating(EatsHand: String, Drink: String) extends Bread


  object DemoCaseClassEx3 {



    def main(args: Array[String]): Unit = {

      println("imherer")

      DemoCaseClassEx3
      // var myclass = Ishuman(2, "looks human", 2);

      println(BreadCheck(Ishuman(2, "deeno", 2)))
      println(BreadCheck(Istaking("hello hello",true)))
      println(BreadCheck(WhatsEating("vag","water")))

    }


    def BreadCheck(breadResult: Bread): String = {

      breadResult match {

        case Ishuman(legs,"deeno",hands) => s"this is human have $legs and looks"
        case Istaking(lang,istak) => s"this bread istalked is $istak and langua is $lang"
        case WhatsEating(food,"water")=>s"this bread eating $food and Drinks water"

        case _=>"0"

      }


    }



}
