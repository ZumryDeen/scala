trait Milkshak{

  def  milk : String


  def flovour: String ={

    "special"
  }


  def description : String

}

trait VenilaMilkShake{

  thisFlavour :Milkshak=>

 // def flovour ="vanila"
  override def description: String = s"Vanila and ${milk}"



}

trait ChocolateFlavour{

  thisFlavour : Milkshak=>

  override def description: String = s"Chocolate and  ${flovour}"



}

trait  MakeShak extends ChocolateFlavour {

  thisMakeShak : Milkshak=>

  override def milk: String = "milky"

  //override def description: String = "makinshake"

  def toping : Boolean = (flovour!="vanilla")


}

object TraitEx{



  def main(args: Array[String]): Unit = {

    println("Hellwo world")
    val shak1 = new Milkshak with VenilaMilkShake with MakeShak
    val ingridiants = shak1.description
val top = shak1.flovour


    println(s"its a shake $ingridiants")
    println(s"Toping is $top")
    val shak2 = new Milkshak with VenilaMilkShake with MakeShak {


      override def description: String = "Milk shake with Vanila"
    }

    val ingridiants2 = shak2.description
    println(ingridiants2 )
  }

}



