

case class Msgtesting (sender : String , mail : String, body :String)

object Demo{

  def main(args: Array[String]): Unit = {


    val msg1 = Msgtesting("deen","deen@gmail.com","hello")

    val msg2 = msg1.copy(sender=msg1.sender,mail = msg1.mail,"im not hello im by" )


    println("this is from Msg1")
    //println(msg1.sender)
    println(msg1.body)

    println("this is from Msg2")
    //println(msg2.sender)
    println(msg2.body)

  }





}