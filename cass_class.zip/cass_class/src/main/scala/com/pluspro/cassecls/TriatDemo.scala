package com.pluspro.cassecls

trait Salary[ValType]{

  def SalTest : Boolean

  def DoVerfiy () : ValType



}

class ProcessSal(Newsal : Int) extends Salary[Int]{

  var CurrentSal = 0

  override def SalTest: Boolean = CurrentSal < Newsal

  override def DoVerfiy(): Int = {

    if(SalTest){

      val x = CurrentSal
      CurrentSal +=1
      x
    } else { 0  }
  }

}



