package com.pluspro.cassecls

abstract class Device




case class phone(model: String) extends Device {
  def screenoff = "turning off on phone"


}




case class PC(model: String) extends Device {

  def screenOn = "Turingin screen on in PC"


}


object Gohibernate{


  def goIdle(device: Device): String = device match {
    case x: phone => x.screenoff
    case y: PC => y.screenOn
  }


  def main(args: Array[String]): Unit = {

    println(goIdle(PC(model = "PC")))

    println(goIdle(phone(model = "PC")))
  }


}
