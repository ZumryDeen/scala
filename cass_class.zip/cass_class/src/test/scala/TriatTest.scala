package com.pluspro.cassecls
import org.scalatest.FunSuite

class TriatTest  extends FunSuite{

test("triat test"){

  val testcase = new  ProcessSal(10)

  assert(testcase.DoVerfiy()==0)
  assert(testcase.DoVerfiy()==0)



}


}
