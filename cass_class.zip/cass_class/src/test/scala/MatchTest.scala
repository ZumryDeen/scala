package com.pluspro.cassecls
// step 1 extend FunSuite
import org.scalatest.FunSuite

class Demotest extends FunSuite{

 test("Assert test"){

   var a = 2
   var b= 1
   var c= 2
   var d = 1

   //assert(a == b || c >= d)
   // Error message: 1 did not equal 2, and 3 was not greater than or equal to 4

   val xs = Seq(1,2,3,5)
   //assert(xs.exists(_==4))
   // Error message: List(1, 2, 3) did not contain 4

   //assert("hello".startsWith("h") && "goodbye".endsWith("y"))
   // Error message: "hello" started with "h", but "goodbye" did not end with "y"

  // assert(num.isInstanceOf[Int])
   // Error message: 1.0 was not instance of scala.Int

  // assert(Some(2).isEmpty)
   // Error message: Some(2) was not empty
 }

test("Match contains"){

  val additionalPeopleTes = Seq("077545454","rrrr","deen@gmail.com")

  val emailmsg  = Email("deen@gmail.com","warning","mail body")


  //assert(notfyTEs.showNotificationEx2(emailmsg,additionalPeopleTes))




}

}
