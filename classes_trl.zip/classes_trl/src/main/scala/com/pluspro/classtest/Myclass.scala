package com.pluspro.classtest

class Myclass {

  def Say(): Unit ={

    println("call me ill come ")

  }

}

object test{

/*  def main(args: Array[String]): Unit = {

    var obj = new Myclass
    obj.Say()
  }*/


}
