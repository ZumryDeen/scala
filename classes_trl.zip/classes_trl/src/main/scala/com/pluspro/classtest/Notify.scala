package com.pluspro.classtest

class Notify extends {

}
