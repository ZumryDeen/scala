package com.plusprotest.classtesting

import org.scalatest.FunSuite

class PersonTst extends FunSuite{

test("Firsname matches New "){

  assert(person_Object.validate(PersonClass("zee","zumry"))=="A")

}

  test("last name simple letter test"){

    assert(person_Object.validate(PersonClass("","zUMRY"))=="B")

  }

  test("Empty val"){

    assert(person_Object.validate(PersonClass("",""))=="C")

  }

  test("Both"){

    assert(person_Object.validate(PersonClass("deen","zumry"))=="E")

  }

}
