package com.plusprotest.classtesting


case class PersonClass(firstName : String , lastName : String)

object person_Object{

  def validate(person_class_Ins : PersonClass): String ={

    val result = person_class_Ins match {

      case PersonClass("deen", _)=>"A"



      case PersonClass("zee", _)=>"A"

      case person_cls_obj: PersonClass if person_cls_obj.lastName.matches("[a-z].*") =>"B"

      case PersonClass("deen","zumry")=>"E"

      case _ => "C"


    }
    result
  }

}







