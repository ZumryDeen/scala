package com.plusprotest.classtesting

abstract class Notification

case class Email(sender: String, title: String, body: String) extends Notification
case class SMS(caller: String, message: String) extends Notification
case class VoiceRec(contactName: String, link: String) extends Notification

object  Notification_mod {

  def show_Notification(obj_notification: Notification): String = {

    obj_notification match {
      case Email(email, title, _) => s"You got an amila from $email with title : $title "
      case SMS(caller, message) => s"you got a $message from thi number $caller"
      case VoiceRec(contactName, link) => s"you got a voice maile from $contactName with this link $link"
    }
  }


  val smsNoty = SMS("077366", "you there ?")
  val voiceNty = VoiceRec("Tom", "voice.com")

  println(show_Notification(smsNoty))
  println(Notification_mod.show_Notification(voiceNty))
}