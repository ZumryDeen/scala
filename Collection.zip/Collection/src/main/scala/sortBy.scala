object sortBy {


  def main(args: Array[String]): Unit = {

val Asds = Map("john"->50,"deen"->30)

println(Asds)

    val weekdaysDub = "wed" :: "tues" :: "monday" ::"monday":: Nil

// sortBy(_(0)) this 0 will take every 1st letter from String and sort adiabatically
    println(weekdaysDub.sortBy(_(0)))
  }




}
