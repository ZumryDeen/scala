object startWith {


  def main(args: Array[String]): Unit = {


    val weekdays = "monday" :: "tues" :: "wed" ::"monday":: Nil
    val weekend = "sat" :: "sun" :: Nil


    val allDays = weekdays++weekend
    val daysdemo = "sat" :: "sun" :: Nil
    println(allDays)

    val ENdwith = allDays endsWith daysdemo
val startwith = allDays startsWith weekdays

    println(ENdwith)
    println(startwith)

  }


}
