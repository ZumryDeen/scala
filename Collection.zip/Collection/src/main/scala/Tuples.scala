object Tuples {

  def main(args: Array[String]): Unit = {


    val persnInfo = ("Zumry", "Deen", "32", "m")

    //1.  accesssing each Eliment of Tuples bu ._
    println(persnInfo._3)

    // 2. looping . productIterator is a keyword

    persnInfo.productIterator.foreach { i => println("Value = " + i) }


    // 3. count all eliment in touples .productArity

    println(persnInfo.productArity)


    // 4. pass tuples as parameter

    (Printgender _).tupled(genderArr)

  }


  // 4 pass tuples as parameter of a function
  // Key     val

  val genderArr = "Deen"->"Male"

  def Printgender (name : String , Gender : String)={

    println(s"Name : $name  ,  Gender: $Gender")


  }

}
