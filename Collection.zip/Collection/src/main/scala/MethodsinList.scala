object MethodsinList {


  def main(args: Array[String]): Unit = {

    val weekdaysDub = "monday" :: "tues" :: "wed" ::"monday":: Nil
    val weekend = "sat" :: "sun" :: Nil


    // 1.1 distinct remove dublicate

    val weekdays = weekdaysDub.distinct



    // use two or more lists with ::: operator
    var allday = weekdays ::: weekend


    //1 , head its r

    println("retunts 1st Eliment of list"+allday.head)

    // 2. tail
    println("retunts list exluding the 1st eliment : "+allday.tail)

    //3. size
    println("size of list  : "+allday.size)


    //4. reverse
    println("reverse of list  : "+allday.reverse)


    // 5. for loop
    for(days<-allday) println(days)



    // foreach loop NOTE : this must be assing for VAR not for VAL

    var ArrayDays = allday

    while (!ArrayDays.isEmpty){

      println(s" today is ${ArrayDays.head}")

      ArrayDays=ArrayDays.tail

    }



    //6. "Drop"   . it will drop from last - first

    val weekdaysDrop = "monday" :: "tues" :: "wed" ::"thursday"  ::"friday" :: Nil

    println("Drop last 2 eliment from list "+weekdaysDrop.drop(2))


    // 7. "slice"    = create a new list with selected element from a list

    val weekdaysSLice = "monday" :: "tues" :: "wed" ::"thursday"  ::"friday" :: Nil

    println("slice eliment 0 to 5 from list "+weekdaysSLice.slice(0,5))

    // 7. "splitAt"    = split the list to sub lists

    println("Split in to 2 List : "+weekdaysSLice.splitAt(2))

    // 8 . " TAKE " this will create a new list with selcted range from 0 t0 ...

    println("Take in to new  List  with 1st 3 eliment 0 - 3  : "+weekdaysSLice.take(3))


    // 9 "sorted " - sorting the list by natural Ex : A - Z

    println("Return new list with natural order : "+weekdaysSLice.sorted)


    println("Return new list with natural order : "+weekdaysSLice.sorted)

  }



}



/*
alvinalexander.com/scala/scala-collections-classes-methods-organized-category
*
*  4) Grouping methods
These methods let you take an existing collection and create multiple groups from that one input collection. These methods include:

groupBy
grouped
partition
sliding
span
splitAt
unzip

5) Informational and mathematical methods
These methods provide information about a collection:

canEqual
contains
containsSlice
count
endsWith
exists
find
forAll
hasDefiniteSize
indexOf
indexOfSlice
indexWhere
isDefinedAt
isEmpty
lastIndexOf
lastIndexOfSlice
lastIndexWhere
max
min
nonEmpty
product
segmentLength
size
startsWith
sum

foldLeft
foldRight
reduceLeft
reduceRight
*
*
*
*
*
* */