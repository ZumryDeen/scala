object MapEx {


  def main(args: Array[String]): Unit = {


    val ages= Map("Salaman"->28,"Shan"->30)



    println("Map created "+ages)

    // to get value of a key in map
    println("Value of key "+ages("Salaman"))




    // 1. check is the key is exsit

    println(ages.contains("Deen"))

    // 2 iterate a Map


    for ((k,v) <- ages) printf("key: %s, value: %s\n", k, v)

    // version 1 (tuples)
    ages foreach (x => println (x._1 + "-->" + x._2))

    // version 2 (foreach and case)
    ages foreach {case (key, value) => println (key + "-->" + value)}


    /* Convert 2 list into a Map as Key and value */


    val Student = List("Salaman","Shan")

    val stutendAge = List(28,30)

    val studentWithage = (Student zip stutendAge).toMap


println("2 lists  converted as Map  " +studentWithage)
// checking maps are ==
    println("checked 2 maps are =  " +studentWithage==ages)

    // to get list of key from map to list
    println("list of key from map : "+studentWithage.keySet.toList)

    // to get list of value from map to list
    println("to get list of value from map to list : "+studentWithage.values.toList)







    /*
    Map and map mathods are diffrent
    working with List and map math */

    val Numlist = List(1,2,3)

      println(Numlist.map{ x=>x*2 })


    println(Numlist.flatMap { x =>
      if (x <= 3) Some(x*2) else None
    })
  }



}
