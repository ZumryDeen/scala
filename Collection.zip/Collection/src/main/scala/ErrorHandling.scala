object ErrorHandling {


  def main(args: Array[String]): Unit = {


    val ages= Map("Salaman"->28,"Shan"->30)



    try {
      ages("wewewew")
    }
    catch {
      //case e: ArithmeticException => println(e)
      case ex: Throwable =>println("Oppps"+ ex)

    } finally {

      println("End , close DB connection")
    }





  }


}
