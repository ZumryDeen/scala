object ScanAndFold {


  def main(args: Array[String]): Unit = {

    //1. "scan"  is return lef - right list by add or deduct as input

    //2. "FOLD "  is return only 1 element from lest which is very left - right or right - left

    //3. "Reduce" is return calculation value of left - right or right - left  Note : its take 2 by 2 values from the list according to the order and its not set an initial value

    val myNumbers = 10 :: 20 :: 30 ::40::50:: Nil
    val myNumbers2 = 10 :: 20 :: 30 ::40::50:: Nil
    // scanRight
    println(myNumbers.scanRight(0)(_ + _))
    // foldRight
    println(myNumbers.foldRight(0)(_ + _))


    // foldRight MAx
    println("foldRight MAx : "+myNumbers2.reduceRight(_ max _))

    // reduceRight
    /*
    10 :: 20 :: 30 ::40::50:

    10+20 =30 , 30+30 =60 , 60+40 = 100 , 100+50=150
    result is 150
    * */
    println("reduceRight"+myNumbers2.reduceRight(_ + _))


    // min

    println("reduceRight Min is : "+myNumbers2.reduceRight(_ min _))


    // scanLeft
    println(myNumbers.scanLeft(0)(_ + _))

    // foldLeft
    println(myNumbers.foldLeft(0)(_ + _))


    // reduceLeft
    println("reduceLeft"+myNumbers2.reduceLeft(_ + _))

    // also we can define the number to add or deduct below case is number 2

    // scan
    println(myNumbers.scan(2)(_ + _))
    // fold
    println(myNumbers.fold(2)(_ + _))

    // reduce
    println("reduce"+myNumbers2.reduce(_ + _))

  }



}
