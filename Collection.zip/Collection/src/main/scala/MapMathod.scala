object MapMathod {

  def main(args: Array[String]): Unit = {
    /*  NOTE : _ this symbol call predicate always return true or false */
    /*  "MAP"    note : its rerun a value so it a function       */
    val weekdays2 = "mon" :: "tue" :: "wed" :: "thu" :: Nil

    // opt -1 check mon is list

    println( weekdays2.map(_ == "monday"))

    // opt - 2 check mon in list


    val checkMondya = (x:String) => {   x=="mon"  } :Boolean

    println(weekdays2.map(checkMondya))

  /* print list with map*/

    val Printdays = (x: String) => {  println(x)  }

    weekdays2.map(Printdays)

  }



}
