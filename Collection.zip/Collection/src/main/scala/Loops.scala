object Loops {


  def main(args: Array[String]): Unit = {

    /*   1. "foreach"   note : Foreach not return a value so its not an fuction its a proceedure               */

    val weekdays = "monday" :: "tues" :: "wed" :: "thursday" :: Nil

    // opt- 1 print as litteral
    weekdays.foreach(println(_))


    // opt - 2


    val showdays = (x: AnyRef) => {
      println(x)
    }

    weekdays.foreach(showdays)


    // FOR loop
    for(days<-weekdays) println("for loop " +days)



  }

}
