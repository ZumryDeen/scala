object partition {


  def main(args: Array[String]): Unit = {


    /*  NOTE : _ this symbol call predicate always return true or false */

    val weekdays = "mon" :: "tue" :: "wed" :: "thu" :: Nil

    val mylist = weekdays.partition(_ !="mon")

// (mylist._1) _1 this is how get 1st function on tuple

    println(mylist)
    println(mylist._1)
    println(mylist._2)

    val showdays = (x: AnyRef) => {
      println(x)
    }


    val newlist = mylist._1
    for(x<-newlist ){

      println(x)

    }


  }

}
