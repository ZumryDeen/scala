object filter {

  def main(args: Array[String]): Unit = {

    /*  NOTE : _ this symbol call predicate always return true or false */

    val weekdays2 = "mon" :: "tue" :: "wed" :: "thu" :: Nil


    /* check mon on list  and delete from the new list */

   // option 1

    println(weekdays2.filter(_ !="mon"))


    // option 2

    val checkMonday = (x :String)=>{ x !="mon"} : Boolean

    println(weekdays2.filter(checkMonday))

  }

}
