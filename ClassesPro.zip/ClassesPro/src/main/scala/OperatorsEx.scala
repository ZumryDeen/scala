


class Mycal(val Num1: Int, val Num2: Int) {

  /*val calNum1 =Num1
  val calNum2 =Num2*/

  // + this can be any name its simple a Def Ex : + = add or calthis
  def +(x: Mycal): Mycal =

    new Mycal(this.Num1 + x.Num1, this.Num2 + x.Num2)


  override def toString = s"($Num1,$Num2)"

}
object demoOperator {

  def main(args: Array[String]): Unit = {
    // Example 1
    val iputset1 = new Mycal(2, 4)

    val inputset2 = new Mycal(6, 1)

    val resultCount = iputset1 + inputset2

    println("Num1 is - "+resultCount.Num1)
    println("Num2 is - "+resultCount.Num2)
    println("Total is - "+resultCount)


  }


}












