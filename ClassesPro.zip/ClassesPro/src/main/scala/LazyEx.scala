


/*
*  Lazy Key word is using for heavy duty val : Ex : a val is getting 1000000 record so its need to run when only they val is called
*  not when the class instantiate with new key work
*
*  belwo my case Lazyprint will only call whe a object call  form LazyBoy alzy boy
*
*  ex : val objLazyBoy = new LazyBoy
*       objLazyBoy.Lazyprint
*
* */
class LazyBoy {


  lazy val Lazyprint  = {  println("Hey im lazy...")  }
val Nonlazy = { println("Im none lazy")  }

}

object LazyEx {
  def main(args: Array[String]): Unit = {


  }
}
