

  case class Mytest[A, B](Mynum: A => B) {
    println(s"Mynum is = $Mynum")  //printed 1st
  }

  object AnonymousClassTest1 extends App {


    val Explainme = Mytest { i: Int =>
      // printed 2nd
      println("hello from the anonymous function")
      i * 2
    }



    // printed 3rd
    val result = Explainme.Mynum(10)
    println(s"result = $result")

  }



