
/*
* Companion Object
*
*   1. scala don't support static method like java because scala have been using in most distribution system ,
*      static methods will have some security breaches
*   2. Companion object will work like static when using factory design
*
* Conditions for use  Companion Object
*
*   1. object name and class name need to be same
*   2. object name and class name needs to be in same file
*   3.
*
*   advantage :
*   all
*
* */
class BankLoging {




  val accountdetailslist =Map("user"->BankLoging.UserName,"pass"->BankLoging.pass,"userType"->BankLoging.usertype)
  def apply = new BankLoging


}


object BankLoging {

  val UserName = "Deen"
  val pass = "123"
  private  val usertype="admin"

  /*BankLoging.UserName
  BankLoging.pass*/



  def main(args: Array[String]): Unit = {

    val objBank= new BankLoging

    println(objBank.accountdetailslist("user"))

for(x<-objBank.accountdetailslist){

  println(x)
  println(x._1)
  println(x._2)
}

  }

}
