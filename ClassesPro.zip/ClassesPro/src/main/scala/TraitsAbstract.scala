abstract class Animal {

  def bread


}


trait Legs {

  def leg


}

trait Food{

  def drink { println("Dinks water and Milk") }
  def likeMilk {}

}

class cat extends Animal with Legs with Food{

  override def bread { println("im a cat Meeyouw!!!!")}

  override def leg: Unit = { println("i have 4 leg")}

  override def drink: Unit = super.drink

  override def likeMilk: Unit = { println("i like milk")}
}

object DemoAnimal{

  val objCat = new cat


  def main(args: Array[String]): Unit = {
    objCat.bread
    objCat.drink
    objCat.leg
    objCat.likeMilk
  }




}