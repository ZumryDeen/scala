
/*
*           class                                     val/def
*
*
* final -   cannot inherited                          cant override
* seald -   can be inherited only in same file
*
* */

class shape(name:String){

     protected val shapename = name

  println("HI im a " + shapename)


}


class ShapeBox(h : Int,w : Int ,shapename : String="Box") extends shape(shapename){

  val hieght = h
  val width = w

  //private val myboxsize = hieght * width
 protected val myboxsize = hieght * width
  //final val myboxsize = hieght * width

  println(myboxsize)
}

class Rectrangle(recH : Int , recW : Int)extends ShapeBox(recH,recH,"Rectrangle"){

  println(myboxsize)

}