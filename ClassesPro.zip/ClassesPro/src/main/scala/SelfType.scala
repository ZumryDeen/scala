/*
* main thing here is i have Not create class for objcrow or objCockatiel
* but using with function on runtime im creating object using available class and trait
* */

class Bird(color: String) {
  println("Hey im a Bird")
}


trait Cantalk {
  def talktohuman {
    println("talk to human")
  }

}

trait Fly {
  self: Bird =>
  def Canfly {
    println("i can fly")
  }
}


class perrot extends Bird(color = "green") with Fly with Cantalk {
  def hello {
    println("Hey im a fresh Parrot")
  }

}


object DemoParrot {
  def main(args: Array[String]): Unit = {
    // this Prrot is a bird can cly and cant talk
    val objParrot = new perrot

    // this crow is Bir and fly but cant talkt
    val objcrow = new Bird(color = "black") with Fly

    // this  Cockatiel only can talk and its a bird but cant Fly
    val objCockatiel = new Bird(color = "blue") with Cantalk


    // parrot object
    println(objParrot.Canfly)
    println(objParrot.hello)
    println(objParrot.talktohuman)

    // crow object
    println(objcrow.Canfly)


    // object objCockatiel

    println(objCockatiel.talktohuman)


  }


}
