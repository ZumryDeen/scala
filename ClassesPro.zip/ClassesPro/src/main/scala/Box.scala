
class BoxMaker(val hieght : Int , val width  : Int) {
  def calBoxsize : Int = hieght * width

}



object demo{
  def main(args: Array[String]): Unit = {
    val boxObj = new BoxMaker(10,5)
println(boxObj.calBoxsize)

  }


}








