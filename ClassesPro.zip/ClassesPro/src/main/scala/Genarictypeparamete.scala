import scala.util.Random

class Genarictypeparametes {

  def StudentName(names : Seq[String]) : String = {
    val randNum = Random.nextInt(names.length)
    names(randNum)


  }

  def genStudentNames[A]( studentSeq : Seq[A] ) : A ={

    val randNums = Random.nextInt(studentSeq.length)
    studentSeq(randNums)


  }

  def StudentNameAny(namess : Any) : Any = {
    //val randNum = Random.nextInt(namess.length)
    //names(randNum)
println(namess)

  }



}


object Gentype{


  def main(args: Array[String]): Unit = {

    val Nameseq = Seq("Deen","Remo","Zumry")
    val Namelist = List(1,2,3,4)





    val genaricTypeOBJ = new Genarictypeparametes

    println("This is from normal type - "+genaricTypeOBJ.StudentName(Nameseq))

    println("This is from Genaric type - "+genaricTypeOBJ.genStudentNames(Namelist))

   // println(genaricTypeOBJ.StudentNameAny(Nameseq))

  }



}