


 abstract class AbShape( name : String) {

   def AbTalk: Unit = {

     println(name)

   }


   def getSize : Int



}

class Shape( name : String) {

//val ShapName = name

  def Talk: Unit = {

    println(name)

  }

}



class Box(Hight :Int , width : Int,ShapNamesxx:String="maBox")  extends Shape(ShapNamesxx){

def Boxtalk: Unit ={

  Talk
  println("My size is "+ Hight*width )

}


}




object Demoshape{

  def main(args: Array[String]): Unit = {

    val objBox = new Box(10,5)

    //objBox.Talk
    objBox.Boxtalk

// Anonymous Class
    val AbstracObjshape = new AbShape("Im not a shape") {
       def getSize: Int = 20
    }

   AbstracObjshape.AbTalk

  }


}