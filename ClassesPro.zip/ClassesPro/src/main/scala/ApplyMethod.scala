

class RedBox(val hieght: Int, val Width: Int) {

  /* val boxHight = hieght
   val boxWidth = Width*/
  println("im RedBox")


}

class RedBoxsize {
  // apply methods working like default value you don't need to call it separately ,  when u call the object it will call asthmatically
  // Ex : objbozsize(objredBox)

  def apply(x: RedBox) = x.hieght * x.Width

  // testin to call x:RedBox as def parameter
  def callbox(x: RedBox): Int = {

    100
  }

}


object DemoApply {

  def main(args: Array[String]): Unit = {

    val objredBox = new RedBox(2, 5)

    val objbozsize = new RedBoxsize()

    println(objbozsize(objredBox))

  }

}